Cave Stalker Zombie Resource Pack

This pack replaces zombie textures with a dark stalker texture.
Use with the server-side Cave Stalker mod.

Server mod behavior:
- Uses vanilla minecraft:zombie as the stalker carrier.
- Removes normal vanilla zombies.
- Allows only zombies tagged cavestalker_stalker.

server.properties example:
resource-pack=<direct URL to this zip>
resource-pack-sha1=<sha1>
require-resource-pack=true
