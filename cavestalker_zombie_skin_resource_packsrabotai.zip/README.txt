Cave Stalker Zombie Skin Resource Pack

Uses your uploaded skin converted from 64x32 legacy player layout to a 64x64 zombie-compatible texture.
Put this pack on clients or set it as the required server resource pack.
